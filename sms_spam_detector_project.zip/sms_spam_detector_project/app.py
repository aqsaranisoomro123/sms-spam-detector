import pickle
from pathlib import Path

import gradio as gr


BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "spam_model.pkl"
VECTORIZER_PATH = BASE_DIR / "tfidf.pkl"

if not MODEL_PATH.exists() or not VECTORIZER_PATH.exists():
    raise FileNotFoundError(
        "Model files are missing. First run: python train_model.py"
    )

with MODEL_PATH.open("rb") as file:
    model = pickle.load(file)
with VECTORIZER_PATH.open("rb") as file:
    tfidf = pickle.load(file)


def predict_spam(message):
    if not message or not message.strip():
        return "Please enter an SMS message."

    message_vector = tfidf.transform([message.strip()])
    prediction = int(model.predict(message_vector)[0])

    if prediction == 1:
        return "Spam Message"
    return "Not Spam (Ham)"


demo = gr.Interface(
    fn=predict_spam,
    inputs=gr.Textbox(lines=4, label="Enter SMS message"),
    outputs=gr.Textbox(label="Prediction"),
    title="SMS Spam Detector",
    description="Enter a text message to check whether it may be spam."
)

if __name__ == "__main__":
    demo.launch()
