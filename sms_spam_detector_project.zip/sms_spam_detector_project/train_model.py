import pickle
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report


DATA_URL = "https://raw.githubusercontent.com/justmarkham/pycon-2016-tutorial/master/data/sms.tsv"


def main():
    print("Loading SMS dataset...")
    df = pd.read_csv(DATA_URL, sep="\t", header=None, names=["label", "message"])
    df = df.dropna(subset=["label", "message"]).copy()
    df["label"] = df["label"].astype(str).str.lower().str.strip()
    df["message"] = df["message"].astype(str).str.strip()
    df = df[df["label"].isin(["ham", "spam"])]

    X = df["message"]
    y = df["label"].map({"ham": 0, "spam": 1})

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    print("Converting text into numbers with TF-IDF...")
    tfidf = TfidfVectorizer()
    X_train_tfidf = tfidf.fit_transform(X_train)
    X_test_tfidf = tfidf.transform(X_test)

    print("Training model...")
    model = MultinomialNB()
    model.fit(X_train_tfidf, y_train)

    predictions = model.predict(X_test_tfidf)
    accuracy = accuracy_score(y_test, predictions)
    print(f"\nModel accuracy: {accuracy * 100:.2f}%")
    print("\nClassification report:")
    print(classification_report(
        y_test, predictions, labels=[0, 1],
        target_names=["Ham (Not Spam)", "Spam"],
        zero_division=0
    ))

    with open("spam_model.pkl", "wb") as file:
        pickle.dump(model, file)
    with open("tfidf.pkl", "wb") as file:
        pickle.dump(tfidf, file)

    print("\nSaved: spam_model.pkl")
    print("Saved: tfidf.pkl")
    print("Training completed successfully.")


if __name__ == "__main__":
    main()
