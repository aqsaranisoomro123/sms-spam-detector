import streamlit as st
import joblib
import re

model = joblib.load('/content/spam_model.pkl')
vectorizer = joblib.load('/content/tfidf.pkl')

st.title("SMS Spam Detector")
st.write("Check whether a message is Spam or Legitimate.")

message = st.text_area("Paste your message here:")

if st.button("Analyze Message"):
    if message.strip():
        clean_message = message.lower()
        clean_message = re.sub(r'http\S+|www\S+', ' URL ', clean_message)
        clean_message = re.sub(r'[^\w\s]', '', clean_message)

        message_vector = vectorizer.transform([clean_message])
        prediction = model.predict(message_vector)[0]

        if prediction == "spam":
            st.error("Spam Message")
            st.write("Risk Level: High")
            st.write("Safety Advice: Avoid links and never share passwords or OTPs.")
        else:
            st.success
